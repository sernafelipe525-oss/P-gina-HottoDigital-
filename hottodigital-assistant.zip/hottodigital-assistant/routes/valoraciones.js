const express = require("express");
const router = express.Router();
const ia = require("../services/iaValoraciones");

// Memoria en RAM por sesion del navegador
const historiales = new Map();

function getHistorial(sessionId) {
  if (!historiales.has(sessionId)) historiales.set(sessionId, []);
  return historiales.get(sessionId);
}
function guardarTurno(sessionId, userMsg, assistantMsg) {
  const h = getHistorial(sessionId);
  h.push({ role: "user", content: userMsg });
  h.push({ role: "assistant", content: assistantMsg });
  while (h.length > 20) h.shift();
}

router.post("/", async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    if (!message || !sessionId) {
      return res.status(400).json({ error: "Falta message o sessionId" });
    }
    const historial = getHistorial(sessionId);
    const respuesta = await ia.procesarMensaje(message, historial);
    guardarTurno(sessionId, message, respuesta);
    res.json({ reply: respuesta });
  } catch (err) {
    console.error("Error en /api/chat-valoraciones:", err);
    res.status(500).json({ error: "Error procesando el mensaje" });
  }
});

module.exports = router;
