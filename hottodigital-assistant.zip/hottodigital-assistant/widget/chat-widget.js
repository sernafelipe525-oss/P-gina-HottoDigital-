/**
 * Widget de chat de Hotto — pega este script antes de </body> en tu web:
 * <script src="chat-widget.js"></script>
 *
 * No requiere nada mas. Crea su propia burbuja flotante y no toca el resto de tu pagina.
 */
(function () {
  const API_URL = "https://buss-production.up.railway.app/api/chat";

  // ---- Sesion del visitante (persiste mientras no borre el navegador) ----
  function getSessionId() {
    let id = localStorage.getItem("hottoChatSession");
    if (!id) {
      id = "web_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      localStorage.setItem("hottoChatSession", id);
    }
    return id;
  }
  const sessionId = getSessionId();

  // ---- Estilos ----
  const style = document.createElement("style");
  style.textContent = `
    .hc-bubble {
      position: fixed; bottom: 20px; right: 20px; z-index: 999999;
      width: 58px; height: 58px; border-radius: 50%;
      background: #f2994a; border: none; cursor: pointer;
      box-shadow: 0 6px 20px rgba(0,0,0,0.35);
      display: flex; align-items: center; justify-content: center;
      font-size: 26px; transition: transform 0.15s ease;
    }
    .hc-bubble:hover { transform: scale(1.06); }
    .hc-panel {
      position: fixed; bottom: 90px; right: 20px; z-index: 999999;
      width: 340px; max-width: calc(100vw - 32px); height: 480px; max-height: calc(100vh - 130px);
      background: #1b1714; border: 1px solid #3d3226; border-radius: 16px;
      display: none; flex-direction: column; overflow: hidden;
      box-shadow: 0 12px 40px rgba(0,0,0,0.45);
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .hc-panel.open { display: flex; }
    .hc-header {
      background: #262019; padding: 14px 16px; border-bottom: 1px solid #3d3226;
      display: flex; align-items: center; justify-content: space-between;
    }
    .hc-header .title { color: #f5efe6; font-weight: 700; font-size: 0.95rem; }
    .hc-header .subtitle { color: #b3a390; font-size: 0.72rem; margin-top: 2px; }
    .hc-header button {
      background: none; border: none; color: #b3a390; font-size: 18px; cursor: pointer; padding: 4px;
    }
    .hc-messages {
      flex: 1; overflow-y: auto; padding: 14px 12px; display: flex; flex-direction: column; gap: 10px;
    }
    .hc-msg {
      max-width: 82%; padding: 9px 12px; border-radius: 12px; font-size: 0.86rem; line-height: 1.4;
      white-space: pre-wrap;
    }
    .hc-msg.bot { background: #262019; color: #f5efe6; align-self: flex-start; border-bottom-left-radius: 3px; }
    .hc-msg.user { background: #f2994a; color: #1b1714; align-self: flex-end; border-bottom-right-radius: 3px; font-weight: 500; }
    .hc-msg.typing { background: #262019; color: #7d6f5c; align-self: flex-start; font-style: italic; }
    .hc-input-bar {
      display: flex; gap: 8px; padding: 10px; border-top: 1px solid #3d3226; background: #1b1714;
    }
    .hc-input-bar input {
      flex: 1; background: #262019; border: 1px solid #3d3226; color: #f5efe6;
      border-radius: 10px; padding: 10px 12px; font-size: 0.86rem; outline: none;
    }
    .hc-input-bar button {
      background: #f2994a; border: none; border-radius: 10px; width: 42px; color: #1b1714;
      font-size: 16px; cursor: pointer; flex-shrink: 0;
    }
    .hc-input-bar button:disabled { opacity: 0.5; cursor: default; }
    @media (max-width: 400px) {
      .hc-panel { right: 16px; bottom: 84px; }
      .hc-bubble { right: 16px; bottom: 16px; }
    }
  `;
  document.head.appendChild(style);

  // ---- Estructura ----
  const bubble = document.createElement("button");
  bubble.className = "hc-bubble";
  bubble.innerHTML = "💬";
  bubble.setAttribute("aria-label", "Abrir chat");

  const panel = document.createElement("div");
  panel.className = "hc-panel";
  panel.innerHTML = `
    <div class="hc-header">
      <div>
        <div class="title">Hotto</div>
        <div class="subtitle">Reservas y pedidos al instante</div>
      </div>
      <button class="hc-close" aria-label="Cerrar">✕</button>
    </div>
    <div class="hc-messages"></div>
    <div class="hc-input-bar">
      <input type="text" placeholder="Escribe tu mensaje..." />
      <button class="hc-send">➤</button>
    </div>
  `;

  document.body.appendChild(bubble);
  document.body.appendChild(panel);

  const messagesEl = panel.querySelector(".hc-messages");
  const inputEl = panel.querySelector("input");
  const sendBtn = panel.querySelector(".hc-send");
  const closeBtn = panel.querySelector(".hc-close");

  let abierto = false;
  let saludado = false;

  function toggle() {
    abierto = !abierto;
    panel.classList.toggle("open", abierto);
    if (abierto && !saludado) {
      saludado = true;
      addMessage("bot", "¡Hola! 👋 Soy el asistente de Hotto. Puedo ayudarte a reservar mesa o hacer un pedido. ¿En qué te ayudo?");
    }
    if (abierto) inputEl.focus();
  }
  bubble.addEventListener("click", toggle);
  closeBtn.addEventListener("click", toggle);

  function addMessage(role, text) {
    const div = document.createElement("div");
    div.className = "hc-msg " + role;
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return div;
  }

  async function enviar() {
    const texto = inputEl.value.trim();
    if (!texto) return;
    inputEl.value = "";
    inputEl.disabled = true;
    sendBtn.disabled = true;

    addMessage("user", texto);
    const typingEl = addMessage("typing", "Escribiendo...");

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: texto, sessionId }),
      });
      const data = await res.json();
      typingEl.remove();
      if (data.reply) {
        addMessage("bot", data.reply);
      } else {
        addMessage("bot", "Uy, algo ha fallado. ¿Puedes intentarlo de nuevo?");
      }
    } catch (err) {
      typingEl.remove();
      addMessage("bot", "No he podido conectar. Comprueba tu conexión e inténtalo de nuevo.");
    } finally {
      inputEl.disabled = false;
      sendBtn.disabled = false;
      inputEl.focus();
    }
  }

  sendBtn.addEventListener("click", enviar);
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") enviar();
  });
})();
