require("dotenv").config();
const express = require("express");
const cors = require("cors");
const webhookRoutes = require("./routes/webhook");
const chatRoutes = require("./routes/chat");
const valoracionesRoutes = require("./routes/valoraciones");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("HottoDigital Assistant activo ✅");
});

app.use("/webhook", webhookRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/chat-valoraciones", valoracionesRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en puerto ${PORT}`);
});
