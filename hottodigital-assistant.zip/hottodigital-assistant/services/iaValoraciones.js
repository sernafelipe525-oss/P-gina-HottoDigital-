const { GoogleGenerativeAI, SchemaType } = require("@google/generative-ai");

const valoraciones = require("./valoraciones");
const { getConfig } = require("./configValoraciones");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

function buildSystemPrompt(config) {
  return `
Eres el asistente virtual de ${config.nombreConsultor}, consultor creativo integral (consultoría comercial para pymes, diseño de marca, diseño web y posicionamiento SEO).

Tu única tarea es ayudar a agendar una "valoración" (una primera cita gratuita de diagnóstico) con ${config.nombreConsultor}.

Datos del servicio:
- Duración de la valoración: ${config.duracionValoracion}.
- Horario disponible: ${config.horarioDisponible}.
- Modalidades: por videollamada, o presencial en Madrid${config.direccionMadrid ? ` (${config.direccionMadrid})` : ""}.

Reglas:
- Habla en español de España, cercano, profesional y breve.
- Pregunta y confirma, antes de agendar: nombre, un contacto (email o teléfono), si prefiere videollamada o presencial en Madrid, y fecha y hora deseadas.
- Si pide presencial fuera de Madrid, explica amablemente que por ahora solo se ofrece presencial en Madrid, y ofrece videollamada como alternativa.
- No inventes disponibilidad horaria exacta: confirma la fecha/hora que pida el cliente y deja la cita en estado pendiente de confirmación.
- Cuando tengas los 5 datos (nombre, contacto, modalidad, fecha, hora), usa la herramienta para agendar.
- Sé breve. Nada de despedidas largas.
`.trim();
}

const tools = [
  {
    functionDeclarations: [
      {
        name: "agendarValoracion",
        description: "Agenda una valoración (cita de diagnóstico) con el consultor.",
        parameters: {
          type: SchemaType.OBJECT,
          properties: {
            nombre: { type: SchemaType.STRING },
            contacto: { type: SchemaType.STRING, description: "Email o teléfono del cliente" },
            modalidad: { type: SchemaType.STRING, description: "'video' o 'presencial'" },
            fecha: { type: SchemaType.STRING, description: "Formato YYYY-MM-DD" },
            hora: { type: SchemaType.STRING, description: "Formato HH:mm, 24h" },
            notas: { type: SchemaType.STRING },
          },
          required: ["nombre", "contacto", "modalidad", "fecha", "hora"],
        },
      },
    ],
  },
];

function getModel(systemPrompt) {
  return genAI.getGenerativeModel({
    model: "gemini-flash-latest",
    systemInstruction: systemPrompt,
    tools,
  });
}

async function ejecutarHerramienta(nombreHerramienta, args) {
  if (nombreHerramienta === "agendarValoracion") {
    const c = await valoraciones.crearValoracion(args);
    return { ok: true, citaId: c.id };
  }
  return { ok: false, error: "Herramienta no reconocida" };
}

function convertirHistorial(historial) {
  return historial.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
}

async function procesarMensaje(textoUsuario, historial = []) {
  const config = await getConfig();
  const systemPrompt = buildSystemPrompt(config);
  const model = getModel(systemPrompt);
  const chat = model.startChat({ history: convertirHistorial(historial) });

  let result = await chat.sendMessage(textoUsuario);
  let response = result.response;
  let calls = response.functionCalls();

  while (calls && calls.length > 0) {
    const respuestasFuncion = [];
    for (const call of calls) {
      const resultado = await ejecutarHerramienta(call.name, call.args);
      respuestasFuncion.push({
        functionResponse: { name: call.name, response: resultado },
      });
    }
    result = await chat.sendMessage(respuestasFuncion);
    response = result.response;
    calls = response.functionCalls();
  }

  return response.text();
}

module.exports = { procesarMensaje };
