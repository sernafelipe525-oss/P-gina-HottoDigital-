const { db } = require("../config/firebase");

/**
 * Crea una valoración (cita) nueva.
 * Estructura en Firebase: /valoraciones/citas/{id}
 */
async function crearValoracion({ nombre, contacto, modalidad, fecha, hora, notas }) {
  const ref = db().ref("valoraciones/citas").push();
  const cita = {
    id: ref.key,
    nombre,
    contacto, // email o telefono que dio el cliente
    modalidad, // "video" | "presencial"
    fecha, // "YYYY-MM-DD"
    hora, // "HH:mm"
    notas: notas || "",
    estado: "pendiente", // pendiente | confirmada | cancelada | realizada
    origen: "web_ai",
    creadoEn: Date.now(),
  };
  await ref.set(cita);
  return cita;
}

module.exports = { crearValoracion };
