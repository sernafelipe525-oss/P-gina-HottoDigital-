const { db } = require("../config/firebase");

let cache = null;
let cacheTime = 0;
const CACHE_MS = 30 * 1000; // 30s: suficiente para no golpear Firebase en cada mensaje,
// y lo bastante corto para que un cambio en el panel se note casi al instante.

async function getConfig() {
  const now = Date.now();
  if (cache && now - cacheTime < CACHE_MS) return cache;

  const snap = await db().ref("configuracion").once("value");
  const data = snap.val() || {};

  cache = {
    nombreRestaurante: data.nombreRestaurante || process.env.RESTAURANT_NAME || "el restaurante",
    direccion: data.direccion || "",
    horario: data.horario || "",
    whatsappPhoneNumberId: data.whatsappPhoneNumberId || process.env.WHATSAPP_PHONE_NUMBER_ID,
    menu: Array.isArray(data.menu) ? data.menu : [],
  };
  cacheTime = now;
  return cache;
}

function invalidarCache() {
  cache = null;
}

module.exports = { getConfig, invalidarCache };
