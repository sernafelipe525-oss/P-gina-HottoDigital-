const { db } = require("../config/firebase");

let cache = null;
let cacheTime = 0;
const CACHE_MS = 30 * 1000;

async function getConfig() {
  const now = Date.now();
  if (cache && now - cacheTime < CACHE_MS) return cache;

  const snap = await db().ref("valoraciones/configuracion").once("value");
  const data = snap.val() || {};

  cache = {
    nombreConsultor: data.nombreConsultor || "Luis Felipe Serna",
    servicios: data.servicios || "Consultoría comercial, diseño de marca, diseño web y posicionamiento SEO.",
    horarioDisponible: data.horarioDisponible || "Lunes a viernes, 10:00 a 18:00 (hora de Madrid).",
    direccionMadrid: data.direccionMadrid || "",
    duracionValoracion: data.duracionValoracion || "30 minutos",
  };
  cacheTime = now;
  return cache;
}

function invalidarCache() {
  cache = null;
}

module.exports = { getConfig, invalidarCache };
